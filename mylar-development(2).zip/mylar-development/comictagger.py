#!/usr/bin/env python
from lib.comictaggerlib.main import ctmain

if __name__ == '__main__':
	ctmain()
